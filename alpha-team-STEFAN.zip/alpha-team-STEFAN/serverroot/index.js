exports.static=function(){
    return true;
}