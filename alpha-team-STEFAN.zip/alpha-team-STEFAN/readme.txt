I have started the back end server using nodejs
server.js is the main file
First make sure you have installed nodejs you can check this by typing in your console: node -v
To install nodejs the command is: npm install nodejs -g
Then to run the server type into your console: node server.js